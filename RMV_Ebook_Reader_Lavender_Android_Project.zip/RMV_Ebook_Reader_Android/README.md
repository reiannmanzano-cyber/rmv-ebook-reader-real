# RMV Ebook Reader — Lavender Android project

The Android Studio project has been updated with the supplied RMV Ebook Reader lavender logo and a matching lavender/purple color theme.

## Features
- Lavender/purple theme and RMV logo on the bookshelf and header
- Import PDF files using Android's document picker
- Import multiple JPG/PNG/WebP image pages
- Local app-private storage for offline reading
- Bookshelf and continue-reading position
- Bookmarks per book
- Zoom controls and pinch-to-zoom
- Swipe/tap navigation with a 3D rotation transition
- Android PdfRenderer for PDF rendering without online PDF libraries

## Build an APK
This environment does not have Android SDK / Gradle build tools, so the APK cannot be compiled here.
1. Download and extract the ZIP.
2. Open the `RMV_Ebook_Reader_Android` folder in Android Studio.
3. Let Android Studio install Android SDK API 35 and sync Gradle.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

## Offline note
After importing, ebook files are copied into the app's private storage and can be read offline. The app does not need an online PDF rendering library. Your library is removed if the app is uninstalled or its app data is cleared.

## Current limitation
The page animation is a 3D rotation transition rather than a physically simulated paper-curl engine. Compile and test the project in Android Studio before daily use.
