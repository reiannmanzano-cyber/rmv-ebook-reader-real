package com.rmv.ebookreader

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Book(val id:String, var title:String, val kind:String, val path:String, var pages:Int, var lastPage:Int=0, val marks:MutableSet<Int> = mutableSetOf())

class MainActivity : Activity() {
    private val bg = Color.rgb(241,231,255)
    private val ink = Color.rgb(75,40,107)
    private val gold = Color.rgb(155,106,214)
    private lateinit var root: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private val books = mutableListOf<Book>()
    private var active: Book? = null
    private var page = 0
    private var scale = 1f
    private var pdf: PdfRenderer? = null
    private var pdfPfd: android.os.ParcelFileDescriptor? = null
    private lateinit var pageImage: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var pageFrame: FrameLayout
    private var downX = 0f
    private var downY = 0f
    private var zoomDetector: ScaleGestureDetector? = null
    private val PDF_REQUEST = 101
    private val IMAGE_REQUEST = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("rmv_reader", Context.MODE_PRIVATE)
        loadBooks()
        showShelf()
    }

    private fun dp(v:Int)= (v * resources.displayMetrics.density).toInt()
    private fun text(s:String, size:Float=16f, color:Int=ink, bold:Boolean=false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold)setTypeface(null, android.graphics.Typeface.BOLD); gravity=Gravity.CENTER_VERTICAL }
    private fun button(s:String, action:()->Unit, primary:Boolean=true): Button = Button(this).apply {
        text=s; textSize=14f; isAllCaps=false; setTextColor(if(primary) Color.WHITE else ink)
        setBackgroundColor(if(primary) ink else Color.rgb(228,211,250)); setPadding(dp(10),dp(5),dp(10),dp(5))
        setOnClickListener { action() }
    }
    private fun base(title:String) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(14),dp(12),dp(14),dp(12)) }
        val header = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(ink); setPadding(dp(12),dp(8),dp(8),dp(8)) }
        val logo=ImageView(this).apply { setImageResource(R.drawable.rmv_logo); scaleType=ImageView.ScaleType.CENTER_CROP; contentDescription="RMV Ebook Reader logo" }
        header.addView(logo, LinearLayout.LayoutParams(dp(44),dp(44)))
        val brand=TextView(this).apply { text="RMV  EBOOK READER"; textSize=17f; setTextColor(Color.WHITE); setTypeface(null,1); setPadding(dp(9),0,0,0) }
        header.addView(brand, LinearLayout.LayoutParams(0,dp(44),1f))
        header.addView(button("My Books",{ closePdf(); showShelf() },false))
        val outer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg) }
        outer.addView(header)
        outer.addView(root, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(outer)
    }
    private fun showShelf() {
        active=null
        base("My Books")
        val logoPanel=FrameLayout(this).apply { setBackgroundColor(Color.rgb(248,242,255)); setPadding(dp(4),dp(4),dp(4),dp(4)) }
        val logoImage=ImageView(this).apply { setImageResource(R.drawable.rmv_logo); scaleType=ImageView.ScaleType.CENTER_CROP; contentDescription="RMV Ebook Reader lavender logo" }
        logoPanel.addView(logoImage,FrameLayout.LayoutParams(-1,-1))
        root.addView(logoPanel,LinearLayout.LayoutParams(-1,dp(210)).apply { bottomMargin=dp(10) })
        val title=text("💜 Your Bookshelf",22f,ink,true); root.addView(title)
        root.addView(text("Read PDFs and image-page ebooks, even offline.",14f,Color.rgb(102,77,124)))
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,dp(12),0,dp(12)) }
        actions.addView(button("+ Import PDF",{ pickPdf() }),LinearLayout.LayoutParams(0,dp(48),1f))
        actions.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
        actions.addView(button("+ Images",{ pickImages() },false),LinearLayout.LayoutParams(0,dp(48),1f))
        root.addView(actions)
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        if(books.isEmpty()) {
            val empty=TextView(this).apply { text="📚\n\nYour bookshelf is waiting.\nImport a PDF or select multiple JPG/PNG pages."; textSize=17f; gravity=Gravity.CENTER; setTextColor(Color.GRAY); setPadding(dp(16),dp(40),dp(16),dp(40)) }
            list.addView(empty)
        } else books.sortedByDescending { it.id }.forEach { b ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(12)); setBackgroundColor(Color.WHITE) }
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            val cover=TextView(this).apply { text=if(b.kind=="PDF") "📕" else "📗"; textSize=34f; gravity=Gravity.CENTER; setBackgroundColor(Color.rgb(241,231,255)) }
            row.addView(cover,LinearLayout.LayoutParams(dp(64),dp(82)))
            val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
            info.addView(text(b.title,17f,ink,true))
            info.addView(text("${b.kind} · ${b.pages} pages",13f,Color.DKGRAY))
            info.addView(text(if(b.lastPage>0) "Continue at page ${b.lastPage+1}" else "Not opened yet",12f,Color.GRAY))
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f)); card.addView(row)
            val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setPadding(0,dp(8),0,0) }
            controls.addView(button("Read / Continue",{ openBook(b) }),LinearLayout.LayoutParams(0,dp(44),1f))
            controls.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
            controls.addView(button("Remove",{ removeBook(b) },false),LinearLayout.LayoutParams(0,dp(44),1f))
            card.addView(controls)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(12); list.addView(card,lp)
        }
        scroll.addView(list); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(text("Books are stored privately on this device. Keep the app installed to keep your library.",11f,Color.GRAY))
    }
    private fun pickPdf(){ startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf" },PDF_REQUEST) }
    private fun pickImages(){ startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="image/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true) },IMAGE_REQUEST) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=Activity.RESULT_OK || data==null) return
        try {
            if(requestCode==PDF_REQUEST) data.data?.let { importPdf(it) }
            if(requestCode==IMAGE_REQUEST) {
                val uris= mutableListOf<Uri>()
                data.clipData?.let { clip -> for(i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) } ?: data.data?.let { uris.add(it) }
                if(uris.isNotEmpty()) importImages(uris)
            }
        } catch(e:Exception) { toast("Could not import that file: ${e.message ?: "unknown error"}") }
    }
    private fun bookDir(id:String)=File(filesDir,"library/$id").apply{mkdirs()}
    private fun safeName(uri:Uri,index:Int):String {
        val mime=contentResolver.getType(uri) ?: ""
        val ext=when { mime.contains("png")->"png"; mime.contains("webp")->"webp"; mime.contains("jpeg")->"jpg"; else -> "img" }
        return "%04d.%s".format(index,ext)
    }
    private fun importPdf(uri:Uri) {
        val id=System.currentTimeMillis().toString()
        val file=File(bookDir(id),"book.pdf")
        contentResolver.openInputStream(uri).use { input -> FileOutputStream(file).use { out -> input!!.copyTo(out) } }
        val pfd=android.os.ParcelFileDescriptor.open(file,android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer=PdfRenderer(pfd); val count=renderer.pageCount; renderer.close(); pfd.close()
        val initial=uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".pdf") ?: "My PDF"
        askToSaveBook(Book(id,initial,"PDF",file.absolutePath,count))
    }
    private fun importImages(uris:List<Uri>) {
        val id=System.currentTimeMillis().toString(); val dir=bookDir(id); val saved=mutableListOf<File>()
        uris.forEachIndexed { i,u ->
            val file=File(dir,safeName(u,i+1))
            contentResolver.openInputStream(u).use { input -> FileOutputStream(file).use { out -> input!!.copyTo(out) } }
            saved.add(file)
        }
        askToSaveBook(Book(id,"My Image Ebook","IMAGES",dir.absolutePath,saved.size))
    }
    private fun askToSaveBook(book:Book) {
        val input=EditText(this).apply { setText(book.title); selectAll(); hint="Book title" }
        android.app.AlertDialog.Builder(this).setTitle("Add to bookshelf").setMessage("Name this book").setView(input)
            .setNegativeButton("Cancel") { _, _ -> File(filesDir,"library/${book.id}").deleteRecursively() }
            .setPositiveButton("Save") { _, _ ->
                book.title=input.text.toString().trim().ifBlank { book.title }
                books.add(book); saveBooks(); showShelf(); toast("Book added to your bookshelf")
            }.show()
    }
    private fun openBook(b:Book) {
        active=b; page=b.lastPage.coerceIn(0,max(0,b.pages-1)); scale=1f
        if(b.kind=="PDF") {
            try { closePdf(); pdfPfd=android.os.ParcelFileDescriptor.open(File(b.path),android.os.ParcelFileDescriptor.MODE_READ_ONLY); pdf=PdfRenderer(pdfPfd!!) }
            catch(e:Exception){toast("Could not open PDF");return}
        }
        showReader()
    }
    private fun showReader() {
        val b=active ?: return
        base(b.title)
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        top.addView(text(b.title,16f,ink,true),LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(button("☆ Bookmark",{ toggleBookmark() },false))
        root.addView(top)
        pageFrame=FrameLayout(this).apply { setBackgroundColor(Color.rgb(86,54,115)); clipChildren=false; clipToPadding=false }
        pageImage=ImageView(this).apply { scaleType=ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.rgb(253,250,255)); setPadding(dp(6),dp(6),dp(6),dp(6)); isClickable=false }
        pageFrame.addView(pageImage,FrameLayout.LayoutParams(-1,-1))
        zoomDetector=ScaleGestureDetector(this,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
            override fun onScale(detector:ScaleGestureDetector):Boolean {scale=(scale*detector.scaleFactor).coerceIn(1f,3.5f);pageImage.scaleX=scale;pageImage.scaleY=scale;return true}
        })
        pageFrame.setOnTouchListener { _,ev ->
            zoomDetector?.onTouchEvent(ev)
            when(ev.action) {
                MotionEvent.ACTION_DOWN -> { downX=ev.x; downY=ev.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx=ev.x-downX; val dy=ev.y-downY
                    if(abs(dx)>dp(45)&&abs(dx)>abs(dy)){ if(dx<0) flip(1) else flip(-1) }
                    else if(ev.x<pageFrame.width*.22f) flip(-1) else if(ev.x>pageFrame.width*.78f) flip(1)
                    true
                }
                else -> true
            }
        }
        root.addView(pageFrame,LinearLayout.LayoutParams(-1,0,1f).apply { topMargin=dp(8); bottomMargin=dp(8) })
        pageLabel=text("",15f,ink,true).apply { gravity=Gravity.CENTER }
        root.addView(pageLabel)
        val controls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        controls.addView(button("‹ Back",{flip(-1)},false),LinearLayout.LayoutParams(0,dp(48),1f))
        controls.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
        controls.addView(button("−",{scale=(scale-.25f).coerceAtLeast(1f);pageImage.scaleX=scale;pageImage.scaleY=scale},false),LinearLayout.LayoutParams(dp(52),dp(48)))
        controls.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
        controls.addView(button("+",{scale=(scale+.25f).coerceAtMost(3.5f);pageImage.scaleX=scale;pageImage.scaleY=scale},false),LinearLayout.LayoutParams(dp(52),dp(48)))
        controls.addView(Space(this),LinearLayout.LayoutParams(dp(8),1))
        controls.addView(button("Next ›",{flip(1)}),LinearLayout.LayoutParams(0,dp(48),1f))
        root.addView(controls)
        root.addView(button("Bookmarks",{showBookmarks()},false))
        renderPage()
    }
    private fun flip(direction:Int) {
        val b=active ?: return
        val target=(page+direction).coerceIn(0,b.pages-1); if(target==page)return
        val old=page
        pageImage.animate().rotationY(if(direction>0) -70f else 70f).alpha(.35f).setDuration(130).withEndAction {
            page=target; renderPage()
            pageImage.rotationY=if(direction>0) 70f else -70f
            pageImage.animate().rotationY(0f).alpha(1f).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        }.start()
    }
    private fun renderPage() {
        val b=active ?: return
        try {
            val bitmap:Bitmap = if(b.kind=="PDF") {
                val renderer=pdf ?: throw IOException("PDF closed")
                val p=renderer.openPage(page)
                val maxWidth=resources.displayMetrics.widthPixels*2
                val ratio=min(2.2f,maxWidth.toFloat()/p.width)
                val bmp=Bitmap.createBitmap(max(1,(p.width*ratio).toInt()),max(1,(p.height*ratio).toInt()),Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE); p.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);p.close();bmp
            } else {
                val dir=File(b.path)
                val file=dir.listFiles()?.filter{it.isFile}?.sortedBy{it.name}?.getOrNull(page) ?: throw IOException("Image missing")
                BitmapFactory.decodeFile(file.absolutePath) ?: throw IOException("Could not decode image")
            }
            pageImage.setImageBitmap(bitmap);pageImage.scaleX=scale;pageImage.scaleY=scale
            pageLabel.text="Page ${page+1} of ${b.pages}  ·  ${((page+1)*100/b.pages)}%"
            b.lastPage=page;saveBooks()
        } catch(e:Exception){toast("Could not display page: ${e.message}")}
    }
    private fun toggleBookmark() {
        val b=active ?: return
        if(!b.marks.add(page)) b.marks.remove(page)
        saveBooks(); toast(if(page in b.marks) "Page bookmarked" else "Bookmark removed")
    }
    private fun showBookmarks() {
        val b=active ?: return
        val marks=b.marks.sorted()
        if(marks.isEmpty()){toast("No bookmarks yet. Tap ☆ Bookmark on a page.");return}
        val labels=marks.map{"Page ${it+1}"}.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Saved bookmarks").setItems(labels){_,which->page=marks[which];renderPage()}.setNegativeButton("Close",null).show()
    }
    private fun removeBook(b:Book) {
        android.app.AlertDialog.Builder(this).setTitle("Remove book?").setMessage("Remove ${b.title} from this device?").setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->File(filesDir,"library/${b.id}").deleteRecursively();books.removeAll{it.id==b.id};saveBooks();showShelf()}.show()
    }
    private fun closePdf(){try{pdf?.close()}catch(_:Exception){};pdf=null;try{pdfPfd?.close()}catch(_:Exception){};pdfPfd=null}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun saveBooks() {
        val arr=JSONArray()
        books.forEach { b -> arr.put(JSONObject().put("id",b.id).put("title",b.title).put("kind",b.kind).put("path",b.path).put("pages",b.pages).put("lastPage",b.lastPage).put("marks",JSONArray(b.marks.toList()))) }
        prefs.edit().putString("books",arr.toString()).apply()
    }
    private fun loadBooks() {
        try {
            val arr=JSONArray(prefs.getString("books","[]"))
            for(i in 0 until arr.length()) { val o=arr.getJSONObject(i);val marks=mutableSetOf<Int>();val ma=o.optJSONArray("marks")?:JSONArray();for(j in 0 until ma.length())marks.add(ma.getInt(j))
                books.add(Book(o.getString("id"),o.getString("title"),o.getString("kind"),o.getString("path"),o.getInt("pages"),o.optInt("lastPage",0),marks)) }
        } catch(_:Exception){}
    }
    override fun onDestroy(){closePdf();super.onDestroy()}
}